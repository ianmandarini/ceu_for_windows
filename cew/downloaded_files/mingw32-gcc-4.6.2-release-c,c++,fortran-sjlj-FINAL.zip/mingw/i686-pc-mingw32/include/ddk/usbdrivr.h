#pragma once

#define USB_KERNEL_IOCTL
#include "usbioctl.h"
#undef USB_KERNEL_IOCTL

#include "usb.h"
#include "usbdlib.h"
#include "usbbusif.h"
